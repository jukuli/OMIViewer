module.exports = {
  output: require('./output')
}
